#include<bits/stdc++.h>
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point.hpp>
#include <boost/geometry/geometries/box.hpp>
#include <boost/geometry/index/rtree.hpp>
#include <vector>
#include <boost/foreach.hpp>
namespace bg = boost::geometry;
namespace bgi = boost::geometry::index;
using namespace std;
typedef bg::model::point<double, 5, bg::cs::cartesian> point;
typedef bg::model::box<point> box;
typedef std::pair<point, int> value;
#define ll long long
#define undef 1e9
#define noise 1e8
unordered_set<int> undefined;
vector<vector<double> > points;
vector<int> labels;
int dim;
double eps,eps1;
bgi::rtree< value, bgi::rstar<16> > rtree;
void get(int i,unordered_set<int> &ans)
{
	point minc,maxc;
	minc.set<0>(points[i][0]-eps1);minc.set<1>(points[i][1]-eps1);minc.set<2>(points[i][2]-eps1);minc.set<3>(points[i][3]-eps1);minc.set<4>(points[i][4]-eps1);
	maxc.set<0>(points[i][0]+eps1);maxc.set<1>(points[i][1]+eps1);maxc.set<2>(points[i][2]+eps1);maxc.set<3>(points[i][3]+eps1);maxc.set<4>(points[i][4]+eps1);
	box b(minc,maxc);
	std::vector<value> result;
	rtree.query(bgi::covered_by(b), std::back_inserter(result));
	for(auto j:result)
	{
		double curd=0;
		int j1=j.second;
		for(int k=0;k<dim;k++)
		{
			curd+=(points[i][k]-points[j1][k])*(points[i][k]-points[j1][k]);
			if(curd>eps)
				break;
		}
		if(curd<=eps)
			ans.insert(j1);
	}
}
void merge(unordered_set<int> &a,unordered_set<int> &b)
{
	for(auto i:b)
		a.insert(i);
}
int main(int argc,char* argv[])
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen(argv[3],"r",stdin);
	freopen("dbscan.txt","w",stdout);
	eps=atof(argv[2]);
	eps1=eps;
	eps*=eps;
	int minp=atoi(argv[1]);
	string line;
	getline(cin,line);
	stringstream sts(line);
	double pnt;
	vector<double> v;
	while(sts>>pnt)
		v.push_back(pnt),dim++;
	int dimtemp=dim;
	while(dimtemp<5)
		v.push_back(0),dimtemp++;
	points.push_back(v);
	while(cin>>pnt)
	{
		v.clear();
		v.push_back(pnt);
		for(int i=0;i<dim-1;i++)
			cin>>pnt,v.push_back(pnt);
		int dimtemp=dim;
		while(dimtemp<5)
			v.push_back(0),dimtemp++;
		points.push_back(v);
	}
	int n=points.size();
	dim=5;
	vector<pair<point,int> > allpoints;
	for(int i=0;i<n;i++)
	{
		point temp;
		temp.set<0>(points[i][0]);temp.set<1>(points[i][1]);temp.set<2>(points[i][2]);temp.set<3>(points[i][3]);temp.set<4>(points[i][4]);
		allpoints.push_back({temp,i});
	}
	bgi::rtree< value, bgi::rstar<16> > rt(allpoints.begin(),allpoints.end());
	rtree=rt;
	vector<int> temp_labels(n,undef);
	labels=temp_labels;
	for(ll i=0;i<n;i++)
		undefined.insert(i);
	int lab=0;
	while(!undefined.empty())
	{
		auto nod=*undefined.begin();
		undefined.erase(undefined.begin());
		if(labels[nod]<undef)
			continue;
		unordered_set<int> nearest;
		get(nod,nearest);
		if(nearest.size()<minp)
		{
			labels[nod]=noise;
			continue;
		}
		labels[nod]=lab;
		while(!nearest.empty())
		{
			vector<int> nxt;
			for(auto i:nearest)
			{
				if(labels[i]==noise)
				{
					labels[i]=lab;
					continue;
				}
				if(labels[i]!=undef)
					continue;
				labels[i]=lab;
				nxt.push_back(i);
			}
			nearest.clear();
			for(auto i:nxt)
			{
				unordered_set<int> next_nearest;
				get(i,next_nearest);
				if(next_nearest.size()>=minp)
					merge(nearest,next_nearest);
			}
		}
		lab++;
	}
	vector<int> all[lab],noise_points;
	for(int i=0;i<n;i++)
	{
		if(labels[i]<noise)
			all[labels[i]].push_back(i);
		else
			noise_points.push_back(i);
	}
	for(ll i=0;i<lab;i++)
	{
		cout<<"#"<<i<<endl;
		for(auto j:all[i])
			cout<<j<<endl;
	}
	if(!noise_points.empty())
	{
		cout<<"#outlier"<<endl;
		for(auto i:noise_points)
			cout<<i<<endl;
	}
}