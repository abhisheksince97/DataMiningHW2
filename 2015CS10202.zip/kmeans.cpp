#include <bits/stdc++.h>
#include <random>

using namespace std;

long double max1(long double a,long double b){
	if(a>b)
		return a;
	return b;
}

long double min1(long double a,long double b){
	if(a>b)
		return b;
	return a;
}

long double dist(long double a,long double b){
	return (a-b)*(a-b);
}

long double eucdist(vector<long double>& a,vector<long double>& b){
	long double ans=0;
	for(int i=0;i<a.size();i++)
		ans+=dist(a[i],b[i]);
	ans = sqrtl(ans);
	return ans;
}

int main(int argc, char **argv){
	// taking input

    srand(time(0));
	fstream fs;
	fs.open(argv[2], std::fstream::in);
	string s; 
	vector<vector<long double> > p;
	while(getline(fs,s)){
		vector<long double> temp;
		p.push_back(temp);
		stringstream ss(s);
	    string token;
	    while (getline(ss, token, ' ')) {
	    	long double tt = stold(token);
	        p[p.size()-1].push_back(tt);
	    }
	}
	fs.close();
	int k = atoi(argv[1]);
	vector<int> cl(p.size(),-1);
	vector<vector<long double> > ce(k,vector<long double>(p[0].size()));

	// assigning random values to cluster centers

    map<int,bool> mp;
    for(int i=0;i<k;i++){
        int ttt = rand()%p.size();
        while(mp.find(ttt)!=mp.end()){
            ttt = rand()%p.size();
        }
        int a_random_int = ttt;
        mp[ttt]=1;
    	ce[i] = p[a_random_int];
    }

    // running kmeans

    while(true){
    	vector<int> prev = cl;
    	for(int i=0;i<p.size();i++){
    		long double mi = LDBL_MAX;
    		int mii = -1;
    		for(int j=0;j<k;j++){
    			long double tempd = eucdist(ce[j],p[i]);
    			if(tempd<mi)
    				mi = tempd,mii=j;
    		}
    		cl[i] = mii;
    	}
    	vector<int> tempc(k,0);
    	for(int i=0;i<k;i++)
    		for(int j=0;j<p[0].size();j++)
    			ce[i][j]=0.0;
    	for(int i=0;i<p.size();i++){
    		tempc[cl[i]]++;
    		for(int j=0;j<p[0].size();j++)
    			ce[cl[i]][j]+=p[i][j];
    	}
    	for(int i=0;i<k;i++)
    		for(int j=0;j<p[0].size();j++)
    			ce[i][j]/=tempc[i]*1.0;
    	bool done=1;
    	for(int i=0;i<p.size();i++)
    		if(cl[i]!=prev[i]){
    			done=0;
    			break;
    		}
    	if(done)
    		break;
    }
    for(int i=0;i<k;i++){
    	cout<<"#"<<i<<endl;
    	for(int j=0;j<p.size();j++)
    		if(cl[j]==i)
    			cout<<j<<endl;
    }
	return 0;
}