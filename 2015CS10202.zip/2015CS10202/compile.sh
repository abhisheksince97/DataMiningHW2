# !/bin/bash
g++ -std=c++11 -O3 kmeans.cpp -o out_kmeans
g++ -I ../boost_1_67_0/ -std=c++11 -O3 optics.cpp -o out_optics
g++ -I ../boost_1_67_0/ -std=c++11 -O3 dbscan.cpp -o out_dbscan
