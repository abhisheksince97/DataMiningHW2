#include<bits/stdc++.h>
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point.hpp>
#include <boost/geometry/geometries/box.hpp>
#include <boost/geometry/index/rtree.hpp>
#include <vector>
#include <boost/foreach.hpp>
namespace bg = boost::geometry;
namespace bgi = boost::geometry::index;
using namespace std;
#define ll long long
#define undef 1e8
#define noise 1e9
typedef bg::model::point<double, 5, bg::cs::cartesian> point;
typedef bg::model::box<point> box;
typedef std::pair<point, ll> value;
unordered_set<ll> indices,undefined;
vector<vector<double> > points;
vector<ll> labels;
double eps;
bgi::rtree< value, bgi::rstar<16> > rtree;
ll n,dim;

class comp{
	public:
	bool operator()(pair<double,ll> &x,pair<double,ll> &y){
		if(x.first<y.first)
			return 0;
		else if(x.first==y.first)
			return x.second>y.second;
		return 1;
	}
};

priority_queue<pair<double,ll> ,vector<pair<double,ll> >, comp> pq;

double dist(vector<double> &v1,vector<double> &v2){
	
	double d=0.0;
	for(ll i=0;i<dim;i++){
		d+=(v1[i]-v2[i])*(v1[i]-v2[i]);
	}
	return sqrt(d);
}

void getN(ll src,double epsilon,vector<pair<double,ll> > &neighbors,vector<vector<double> > &points){

	point minc,maxc;
	double eps1=epsilon;
	// double eps1=sqrt(eps);
	minc.set<0>(points[src][0]-eps1);minc.set<1>(points[src][1]-eps1);minc.set<2>(points[src][2]-eps1);minc.set<3>(points[src][3]-eps1);minc.set<4>(points[src][4]-eps1);
	maxc.set<0>(points[src][0]+eps1);maxc.set<1>(points[src][1]+eps1);maxc.set<2>(points[src][2]+eps1);maxc.set<3>(points[src][3]+eps1);maxc.set<4>(points[src][4]+eps1);
	box b(minc,maxc);
	std::vector<value> result;
	rtree.query(bgi::covered_by(b), std::back_inserter(result));
	eps1*=eps1;
	for(auto j:result)
	{
		double curd=0;
		ll j1=j.second;
		for(ll k=0;k<dim;k++)
		{
			curd+=(points[src][k]-points[j1][k])*(points[src][k]-points[j1][k]);
			if(curd>eps1)
				break;
		}
		if(curd<=eps1)
			neighbors.push_back({sqrt(curd),j1});
	}
	// double d;
	// for(ll i=0;i<n;i++){
	// 	d=dist(points[src],points[i]);
	// 	if(d<=epsilon){
	// 		neighbors.push_back({d,i});
	// 	}
	// }
}

double core_dist(ll src,double epsilon,ll minpts,vector<pair<double,ll> > neighbors){

	double cd;
	if(neighbors.size()<minpts){
		cd=-1.0;
	}
	else{
		sort(neighbors.begin(),neighbors.end());
		cd=neighbors[minpts-1].first;
	}
	return cd;
}

void update(ll src,double epsilon,ll minpts,vector<vector<double> > &points,
	vector<double> &reach_dist,vector<pair<double,ll> > &neighbors,vector<bool> &visited){

	double cd=core_dist(src,epsilon,minpts,neighbors);
	double new_reach_dist;
	for(auto it:neighbors){
		ll o=it.second;
		if(visited[o])
			continue;
		new_reach_dist=max(cd,dist(points[src],points[o]));
		if(reach_dist[o]==-1){
			reach_dist[o]=new_reach_dist;
			pq.push({new_reach_dist,o});
		}
		else{
			if(new_reach_dist<reach_dist[o]){
				reach_dist[o]=new_reach_dist;
				pq.push({new_reach_dist,o});
			}
		}
	}
}

void optics(vector<vector<double> > &points,vector<double> &reach_dist,
	vector<ll> &ordered_list,double epsilon,ll minpts){

	vector<bool> visited(n,0);

	for(ll i=0;i<n;i++){
		if(visited[i])
			continue;
		vector<pair<double,ll> > neighbors;
		getN(i,epsilon,neighbors,points);
		visited[i]=1;
		ordered_list.push_back(i);
		ll cd=core_dist(i,epsilon,minpts,neighbors);
		if(cd!=-1.0){
			while(!pq.empty()){
				pq.pop();
			}
			update(i,epsilon,minpts,points,reach_dist,neighbors,visited);
			while(!pq.empty()){
				auto curr=pq.top();
				pq.pop();
				ll it=curr.second;
				if(visited[it])
					continue;
				vector<pair<double,ll> > neighbors_new;
				getN(it,epsilon,neighbors_new,points);
				visited[it]=1;
				ordered_list.push_back(it);
				ll cd_new=core_dist(it,epsilon,minpts,neighbors_new);
				if(cd_new!=-1){
					update(it,epsilon,minpts,points,reach_dist,neighbors_new,visited);
				}
			}
		}
	} 
}

int main(int argc, char * argv[]){

	ll minpts=atol(argv[1]);
	double epsilon=atof(argv[2]);
	char* filename=argv[3];
	ifstream myfile(filename);
	string line;
	string word;
	double x;
	vector<vector<double> > points;
	vector<double> temp;
	if(myfile.is_open()){
		while(getline(myfile,line)){
			stringstream ss(line);
			temp.clear();
			while(ss >> word){
				x=stof(word);
				temp.push_back(x);
			}
			points.push_back(temp);
		}
	}
	n=points.size();
	dim=points[0].size();
	for(ll i=0;i<n;i++){
		for(ll j=dim;j<5;j++){
			points[i].push_back(0);
		}
	}
	vector<pair<point,ll> > allp;
	for(ll i=0;i<n;i++)
	{
		point temp1;
		temp1.set<0>(points[i][0]);temp1.set<1>(points[i][1]);temp1.set<2>(points[i][2]);temp1.set<3>(points[i][3]);temp1.set<4>(points[i][4]);
		// rtree.insert({temp1,i});
		allp.push_back({temp1,i});
	}
	bgi::rtree< value, bgi::rstar<16> > temptree(allp.begin(),allp.end());
	rtree=temptree;
	vector<double> reach_dist(n,-1);
	vector<ll> ordered_list;
	optics(points,reach_dist,ordered_list,epsilon,minpts);
	FILE* fp=fopen("temp_out.txt","w+");
	for(ll i=0;i<ordered_list.size();i++){
		fprintf(fp, "%lf \n", reach_dist[ordered_list[i]]);
	}
	fclose(fp);
}