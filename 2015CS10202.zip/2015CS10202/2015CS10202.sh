#!/bin/bash
if [ $1 = "-kmeans" ]
then
	./out_kmeans $2 $3 > kmeans.txt
elif [ $1 = "-dbscan" ]
then
	./out_dbscan $2 $3 $4
elif [ $1 = "-optics" ]
then
	./out_optics $2 $3 $4
	python optics.py
else
	"Wrong Arguments"
fi