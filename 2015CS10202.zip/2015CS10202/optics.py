import numpy as np
import matplotlib.pyplot as plt
data = np.genfromtxt("temp_out.txt")
max_val=max(np.max(data)*2.0,0.0)
for i in range(len(data)):
	if data[i]==-1.0:
		data[i]=max_val
fig = plt.figure()
ax = fig.add_subplot(111)
figname='Reachability Distance vs Nodes'
plt.title(figname)
ax.set_xlabel('Nodes')
ax.set_ylabel('Reachability Distance')
ax.plot(data,'b')
plt.show()